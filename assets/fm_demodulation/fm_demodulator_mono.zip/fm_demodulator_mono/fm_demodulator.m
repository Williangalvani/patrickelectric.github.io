%freq = 100.9e6 % a radio do momento
%fs = 1.8e6     % freq de amostragem

% fm_demodulator('./capture2.bin',1.8e6,10)
function fm_demodulator(read_file,fs,time)  
  fid = fopen(read_file,'rb');        % read the file
  y = fread(fid,'uint8=>double');     % transform the bytes to a double
  y = y-127;                     % change udouble to double
  % s_i(t) + j*s_q(t)
  yi = y(1:2:end)+1i*y(2:2:end);  % convert IQ data to an imaginary number
  ysize=size(yi);
  ysize=ysize(1);

  % take the time to play
  if(time*fs>ysize)  
    k=ysize;
  else
    k=time*fs;
  end
  
  % phi = angle(s_i(t) + j*s_q(t))
  yang = angle(yi(1:k)); % calculate yi angle (-pi,pi)
  yrap = unwrap(yang);   % make the angle continuous (-inf,+inf)
  % m(t) = (1/(2*pi*kf))*(dphi/dt) 
  tdev = diff(yrap);     % calculate the derivative
 
  % fft 
  tdfft = fft(tdev);
  P2=abs(tdfft/ysize);
  P1=P2(1:ysize/2+1);
  P1(2:end-1)=2*P1(2:end-1);
  f=fs*(0:(ysize/2))/ysize;
  % plot the fft until 18.5kHz
  freqe=round(2*18.5e3*size(f)/fs);
  freqe=freqe(2);
  plot(f(1:freqe),20*log10(P1(1:freqe)))
  grid on
  xlabel 'freq Hz',ylabel 'dB'
  
  % play the music
  % convert the fs to play (some softwares have a limit of sample rate)
  if((exist('OCTAVE_VERSION', 'builtin')~=0))
    sound(tdev,fs)   
  else
    saida = decimate(tdev,10);
    sound(saida,fs/10)
  end     
 
end
